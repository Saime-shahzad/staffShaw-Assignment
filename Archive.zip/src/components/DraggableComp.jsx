import React from "react";
import DraggableList from "react-draggable-lists";

import "./DraggableStyles.css";

const style = {}

const DraggableComp = () => {
  const listItems = [
    "Entertainment",
    "Private Time",
    "Rest",
    "Meal",
    "Exercise",
    "Work",
    "Home Projects",
    "Family",
  ];

  const onMoveEnd = (newList) => {
    console.log(newList);
  };
  return (
    <div className="App">
      <div style={{ width: 300, margin: "0 auto" }} className="custome-list">
        <DraggableList
          width={300}
          height={50}
          rowSize={1}
          onMoveEnd={onMoveEnd}
        >
          {listItems.map((item, index) => (
            <li key={index}>{`${index + 1}.  ${item}`}</li>
          ))}
        </DraggableList>
      </div>
    </div>
  );
};

export default DraggableComp;
