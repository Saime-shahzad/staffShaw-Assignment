import React, { useState, useEffect } from "react";
import ReactApexChart from "react-apexcharts";

const ApexChartFunctional = ({ seriesData, categories }) => {
  // Initialize state using useState hook
  const [state, setState] = useState({
    series: seriesData,
    options: {
      chart: {
        type: "bar",
        height: 350,
        stacked: true,
        stackType: "100%",
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            legend: {
              position: "bottom",
              offsetX: -10,
              offsetY: 0,
            },
          },
        },
      ],
      xaxis: {
        categories: categories,
      },
      fill: {
        opacity: 1,
      },
      legend: {
        position: "right",
        offsetX: 0,
        offsetY: 50,
      },
    },
  });

  // Function to update the state (if needed)
  const updateState = () => {
    // Example of updating state, remove if not needed
    setState((prevState) => ({
      ...prevState,
      series: [
        {
          ...prevState.series[0],
          data: [...prevState.series[0].data, Math.floor(Math.random() * 100)],
        },
      ],
    }));
  };

  // Effect hook to perform side effects (e.g., mounting component)
  useEffect(() => {
    // This can be used to perform actions after the component mounts
    // For example, initializing some external libraries or fetching data
  }, []); // Empty dependency array means this effect runs once on mount

  return (
    <div>
      <div id="chart">
        <ReactApexChart
          options={state.options}
          series={state.series}
          type="bar"
          height={350}
        />
      </div>
      <div id="html-dist"></div>
    </div>
  );
};

export default ApexChartFunctional;
