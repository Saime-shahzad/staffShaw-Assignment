import React from "react";

const TopBar = () => {
  return (
    <div
      id="kt_app_toolbar"
      className="app-toolbar py-4 py-lg-6 mb-8 mb-lg-10 bg-white "
      style={{ marginLeft: "-20%", zIndex: "999999" }}
    >
      {/*begin::Toolbar container*/}
      <div
        id="kt_app_toolbar_container"
        className="app-container container-xxl d-flex flex-stack flex-wrap flex-lg-nowrap gap-4"
        style={{ marginLeft: 0 }}
      >
        {/*begin::Toolbar wrapper*/}
        <div className="d-flex align-items-center">
          {/*begin::Logo*/}

          {/*end::Logo*/}
          {/*begin::Page title*/}
          <div className="page-title py-2 py-sm-0 d-flex flex-column justify-content-center me-3">
            {/*begin::Title*/}
            <h1 className="page-heading d-flex text-gray-900  fs-7 flex-column justify-content-center my-0">
              <span className="text-muted">
                Projects {">"} Dashboard {">"} 2022 Inventory Dashboard
              </span>
              {/*begin::Description*/}
              <span className="page-desc fw-semibold pt-2 fs-1">
                2022 Inventory Dashboard
              </span>
              {/*end::Description*/}
            </h1>
            {/*end::Title*/}
          </div>
          {/*end::Page title*/}
        </div>
        {/*end::Toolbar wrapper-*/}
        {/*begin::Toolbar wrapper-*/}
        <div className="d-flex align-items-center flex-wrap flex-lg-nowrap gap-4 gap-lg-10">
          <div className="d-flex align-items-center gap-2 gapl-lg-4">
            {/*begin::Secondary button*/}
            <div className="m-0">
              {/*begin::Menu*/}
              <a
                href="#"
                className="btn btn-flex btn-sm h-40px btn-light fw-bold"
                data-kt-menu-trigger="click"
                data-kt-menu-placement="bottom-end"
              >
                Decline
              </a>
              {/*begin::Menu 1*/}
              <div
                className="menu menu-sub menu-sub-dropdown w-250px w-md-300px"
                data-kt-menu="true"
                id="kt_menu_667af5e28ae1a"
              >
                {/*begin::Header*/}
                <div className="px-7 py-5">
                  <div className="fs-5 text-gray-900 fw-bold">
                    Filter Options
                  </div>
                </div>
                {/*end::Header*/}
                {/*begin::Menu separator*/}
                <div className="separator border-gray-200" />
                {/*end::Menu separator*/}
                {/*begin::Form*/}
                <div className="px-7 py-5">
                  {/*begin::Input group*/}
                  <div className="mb-10">
                    {/*begin::Label*/}
                    <label className="form-label fw-semibold">Status:</label>
                    {/*end::Label*/}
                    {/*begin::Input*/}
                    <div>
                      <select
                        className="form-select form-select-solid"
                        multiple
                        data-kt-select2="true"
                        data-close-on-select="false"
                        data-placeholder="Select option"
                        data-dropdown-parent="#kt_menu_667af5e28ae1a"
                        data-allow-clear="true"
                      >
                        <option />
                        <option value={1}>Approved</option>
                        <option value={2}>Pending</option>
                        <option value={2}>In Process</option>
                        <option value={2}>Rejected</option>
                      </select>
                    </div>
                    {/*end::Input*/}
                  </div>
                  {/*end::Input group*/}
                  {/*begin::Input group*/}
                  <div className="mb-10">
                    {/*begin::Label*/}
                    <label className="form-label fw-semibold">
                      Member Type:
                    </label>
                    {/*end::Label*/}
                    {/*begin::Options*/}
                    <div className="d-flex">
                      {/*begin::Options*/}
                      <label className="form-check form-check-sm form-check-custom form-check-solid me-5">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          defaultValue={1}
                        />
                        <span className="form-check-label"> Author </span>
                      </label>
                      {/*end::Options*/}
                      {/*begin::Options*/}
                      <label className="form-check form-check-sm form-check-custom form-check-solid">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          defaultValue={2}
                          defaultChecked="checked"
                        />
                        <span className="form-check-label">Customer</span>
                      </label>
                      {/*end::Options*/}
                    </div>
                    {/*end::Options*/}
                  </div>
                  {/*end::Input group*/}
                  {/*begin::Input group*/}
                  <div className="mb-10">
                    {/*begin::Label*/}
                    <label className="form-label fw-semibold">
                      Notifications:
                    </label>
                    {/*end::Label*/}
                    {/*begin::Switch*/}
                    <div className="form-check form-switch form-switch-sm form-check-custom form-check-solid">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        defaultValue
                        name="notifications"
                        defaultChecked
                      />
                      <label className="form-check-label">Enabled</label>
                    </div>
                    {/*end::Switch*/}
                  </div>
                  {/*end::Input group*/}
                  {/*begin::Actions*/}
                  <div className="d-flex justify-content-end">
                    <button
                      type="reset"
                      className="btn btn-sm btn-light btn-active-light-primary me-2"
                      data-kt-menu-dismiss="true"
                    >
                      Reset
                    </button>
                    <button
                      type="submit"
                      className="btn btn-sm btn-primary"
                      data-kt-menu-dismiss="true"
                    >
                      Apply
                    </button>
                  </div>
                  {/*end::Actions*/}
                </div>
                {/*end::Form*/}
              </div>
              {/*end::Menu 1*/}
              {/*end::Menu*/}
            </div>
            {/*end::Secondary button*/}
            {/*begin::Primary button*/}
            <a
              href="#"
              className="btn btn-flex btn-sm h-40px fw-bold"
              style={{background: "#824CEE", color: "#fff"}}
            >
              Complete
            </a>
            {/*end::Primary button*/}
          </div>
          {/*end::Actions*/}
        </div>
        {/*end::Toolbar wrapper-*/}
      </div>
      {/*end::Toolbar container*/}
    </div>
  );
};

export default TopBar;
