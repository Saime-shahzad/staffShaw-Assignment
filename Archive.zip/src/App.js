import React from "react";
// import { Provider } from "react-redux";
// import { BrowserRouter as Router } from "react-router-dom";
// import SearchBar from "./components/SearchBar";
// import Map from "./components/Map";
// import store from "./store/store";
import Home from "./pages/Home";

function App() {
  return <Home />;
  // return (
  //   <Provider store={store}>
  //     <Router>
  //       <div className="App">

  //       </div>
  //     </Router>
  //   </Provider>
  // );
}

export default App;
