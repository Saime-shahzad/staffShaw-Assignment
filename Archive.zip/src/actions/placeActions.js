import { GOOGLE_MAP_API_KEY } from "../utils";
import {
  FETCH_PLACES_REQUEST,
  FETCH_PLACES_SUCCESS,
  FETCH_PLACES_FAILURE,
} from "./types.js";
import axios from 'axios';


export const fetchPlacesRequest = () => ({
  type: FETCH_PLACES_REQUEST,
});

export const fetchPlacesSuccess = (places) => ({
  type: FETCH_PLACES_SUCCESS,
  payload: places,
});

export const fetchPlacesFailure = (error) => ({
  type: FETCH_PLACES_FAILURE,
  payload: error,
});



export const fetchPlaces = (query) => {
  console.log("query >>", query);
  return async (dispatch) => {
    dispatch(fetchPlacesRequest());

    try {
      const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${query}&key=${GOOGLE_MAP_API_KEY}`;
      const response = await axios.get(url);
      dispatch(fetchPlacesSuccess(response.data.predictions)); // Get predictions from API response
    } catch (error) {
      dispatch(fetchPlacesFailure(error.message));
    }
  };
};


// export const fetchPlaces = (query) => {
//     console.log("query >>", query);
//   return (dispatch) => {
//     dispatch(fetchPlacesRequest());
//     const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${query}&key=${GOOGLE_MAP_API_KEY}`;

//     fetch(url)
//       .then((response) => {
//         if (!response.ok) {
//           throw new Error("Network response was not ok");
//         }
//         return response.json();
//       })
//       .then((data) => {
//         dispatch(fetchPlacesSuccess(data.predictions)); // Get predictions from API response
//       })
//       .catch((error) => {
//         dispatch(fetchPlacesFailure(error.message));
//       });
//   };
// };
