import React from "react";

const Header = () => {
  return (
    <div
      id="kt_app_header"
      className="app-header d-flex d-lg-none"
      data-kt-sticky="true"
      data-kt-sticky-activate="{default: false, lg: true}"
      data-kt-sticky-name="app-header-sticky"
      data-kt-sticky-offset="{default: false, lg: '300px'}"
      
    >
      {/*begin::Header container*/}
      <div
        className="app-container container-xxl d-flex align-items-center justify-content-between"
        id="kt_app_header_container"
      >
        {/*begin::Logo*/}
        <div className="d-flex align-items-center flex-grow-1 flex-lg-grow-0 me-lg-15">
          <a href="index.html">
            <img
              alt="Logo"
              src="assets/media/logos/demo-29-small.svg"
              className="h-30px"
            />
          </a>
        </div>
        {/*end::Logo*/}
        {/*begin::Header mobile toggle*/}
        <div
          className="d-flex align-items-center d-lg-none ms-2 me-n3"
          title="Show sidebar menu"
        >
          <div
            className="btn btn-icon btn-color-white bg-white bg-opacity-0 bg-hover-opacity-10 w-35px h-35px"
            id="kt_app_sidebar_mobile_toggle"
          >
            <i className="ki-outline ki-abstract-14 fs-1" />
          </div>
        </div>
        {/*end::Header mobile toggle*/}
      </div>
      {/*end::Header container*/}
    </div>
  );
};

export default Header;
